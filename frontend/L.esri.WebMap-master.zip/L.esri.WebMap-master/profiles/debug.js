import config from './base.js';

config.dest = 'dist/esri-leaflet-webmap-debug.js';
config.sourceMap = 'inline';

export default config;
